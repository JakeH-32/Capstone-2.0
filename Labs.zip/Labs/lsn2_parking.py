from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Parking Sign
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a program that prints a formatted "No parking" sign.  
# See Lab writeup for exact spacing.
# ---------------------------------------------------------------------

# YOUR CODE GOES BELOW
