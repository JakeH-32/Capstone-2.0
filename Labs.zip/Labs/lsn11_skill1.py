from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 11 - Fundamental Skill #1
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Create a list called my_list.  Put 3 items inside the list (they can be anything you want)
# ---------------------------------------------------------------------
