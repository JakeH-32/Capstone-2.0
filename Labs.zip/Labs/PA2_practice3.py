from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Practice Question #3
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python Program that analyzes the Body Mass
# Index (BMI) of a group of cadets.  Your program should ask the user for
# the number of cadets to analyze, and then ask for that many weights and
# heights (in that order).  Your program should print out the number of
# individuals whose BMI is thin, healthy, overweight, and obese.
#
# Refer to the lab description for more details.
# ---------------------------------------------------------------------




