from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Titanic Survivor
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm identifies the individual who survived,
# and paid the lowest fare.
# ---------------------------------------------------------------------
