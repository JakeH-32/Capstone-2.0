from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Runways
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python program that asks the user for the
# name of the file containing the Runways dataset, as well as the length
# and width of the runway.  Your program should print the Location ID of
# every runway whose length and width meets or exceeds the specified values. 
# ---------------------------------------------------------------------

