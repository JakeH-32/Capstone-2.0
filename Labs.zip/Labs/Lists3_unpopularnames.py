from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Unpopular Names (by Gender)
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a Python algorithm that gets a gender (all CAPs, "MALE" or "FEMALE")
# and a number, X, from the user, and prints out the X least popular
# names for that gender, starting with the most popular and working down.
# ---------------------------------------------------------------------
