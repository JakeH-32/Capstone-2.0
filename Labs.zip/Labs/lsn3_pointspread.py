from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: IPO:  Point Spread
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write an algorithm that prompts the user for two
# sports game scores and outputs the point spread.  The point spread
# should always be positive.
# ---------------------------------------------------------------------
