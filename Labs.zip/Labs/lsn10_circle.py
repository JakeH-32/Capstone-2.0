from cs110 import autograder
import math

# ---------------------------------------------------------------------
# Lab: Function - Area of Circle
# Course: CS110
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# Problem Statement:  Write a function that computes the area of a circle.
# You will name your function area_circle. It has one parameter, the radius
# of the circle, radius. The area_circle() function will return the area of the circle.
# ---------------------------------------------------------------------

