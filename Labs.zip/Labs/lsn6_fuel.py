from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 6, Bingo Fuel
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that prompts the user for a fuel
# load (in lbs) and a distance to base (in nautical miles) to base and then
# outputs what kind of action the pilot should take. See lab for details.
# ---------------------------------------------------------------------