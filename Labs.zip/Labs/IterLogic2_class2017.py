from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Class of 2017
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that first asks the user how many
# cadets to input and then gets that many cadet class years from the user.
# Output how many of those cadets were in the class of 2017. 
# ---------------------------------------------------------------------

