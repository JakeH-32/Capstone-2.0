from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 3 - Fundamental Skill #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# 1.  Write a program that gets a user's age as an integer, and stores it in a variable (name it whatever you want)
# 2.  Print the user's age + 4. 
# ---------------------------------------------------------------------

