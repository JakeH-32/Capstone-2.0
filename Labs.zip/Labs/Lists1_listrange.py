from cs110 import autograder
import math

# ---------------------------------------------------------------------
# Lab: List Range
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement: get a start and stop number from the user, first
#  print out the range of values as a list, second print out how many numbers are in the list
#  See Lab for exact specification.
# ---------------------------------------------------------------------

