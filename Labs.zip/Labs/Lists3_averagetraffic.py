from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Average Traffic
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a Python algorithm that opens the file and outputs the number of roads
# whose traffic count is greater than (or equal to) the average.
# ---------------------------------------------------------------------
