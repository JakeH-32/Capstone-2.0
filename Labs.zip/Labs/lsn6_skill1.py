from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 6 - Fundamental Skill #1
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a program that gets the user's body temperature
# If the body temperature is between 97-99 (inclusive), print "Normal".  Otherwise, print
# "Abnormal"
# ---------------------------------------------------------------------

# THIS LINE IS GOOD.  DO NOT TOUCH!
body_temperature = float(input())

# YOUR CODE BEGINS HERE
