from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Print Practice
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement: Write the print statements needed to print the appropriate
# strings (see below for details)
# ---------------------------------------------------------------------

# Print the phrase "Welcome to Computer Science 110!"


# Print the result to the following math expression:  (640 * 480 * 24) / 8


# Use the variables below to print the phrase:  "Liam is 8 years old"
name = "Liam"
age = 8


# Use a single print statement to print out the following (hint: watch the spaces!!!):
# F-15  Eagle
# F-16  Fighting Falcon
# B-2   Spirit
# C-141 Starlifter
