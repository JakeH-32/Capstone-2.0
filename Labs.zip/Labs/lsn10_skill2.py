from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 10 - Fundamental Skill #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a function called fahrenheit_to_kelvin.  Your function should take
# a temperature (in Fahrenheit) as a parameter, and RETURN (NOT PRINT) the
# equivalent temperature in Kelvin.
#
# The formula for converting between Fahrenheit and Kelvin is
# K = ((F - 32) / 1.8) + 273.15
# ---------------------------------------------------------------------

# Your Code Goes Here

