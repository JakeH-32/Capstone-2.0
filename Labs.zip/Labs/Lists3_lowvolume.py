from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Low Volume Traffic
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement: Write a Python algorithm that opens the file traffic.csv
# and outputs the lowest traffic count. Then output the  names of all streets
# whose traffic count is within 2500 (inclusive) of the min. Output one street
# name per line.
# ---------------------------------------------------------------------

