from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: SAT Performance
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a Python algorithm that calculates the average SAT score across
# all schools, and outputs the names of schools that are below the average.  
# ---------------------------------------------------------------------
