from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Count by 10s
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# LOGIC DESIGN
# Problem Statement:  Write an algorithm that whose input
# is two integers. Output the first integer and subsequent increments of
# 10 as long as the value is less than or equal to the second integer. 
# ---------------------------------------------------------------------

