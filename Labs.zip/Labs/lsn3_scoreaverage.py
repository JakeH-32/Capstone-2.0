from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: IPO:  Score Average
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write an algorithm that prompts the user for three
# sports game scores and outputs average.  The point spread should always
# be positive.
# ---------------------------------------------------------------------

