from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Practice Question #1
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Define a function called add_values. The function
# should take 3 parameters (x, y, z), and return the sum of these values.
# ---------------------------------------------------------------------

# Create your function here
