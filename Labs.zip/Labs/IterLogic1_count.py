from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Count
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that gets 2 inputs from the user:
# 1) a number, and
# 2) an increment amount.
# Your program will then print out all the numbers from 0 to the user-defined
# value, counting by the increment amount.
# ---------------------------------------------------------------------



