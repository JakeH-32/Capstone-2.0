from cs110 import autograder

# ---------------------------------------------------------------------
# Lab Lesson 5: Largest Number
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a program that gets three numbers from the
# user, and prints the largest one.
# ---------------------------------------------------------------------
