from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Temperature
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that prompts the user for a temperature in �F
# and then outputs K and �C in that order.
# ---------------------------------------------------------------------
