from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 9 - Fundamental Skill #3
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Define a function called print_hello that, when called, simply prints a friendly message.
# ---------------------------------------------------------------------

# Write Your Code Here



# TEST CODE.  DO NOT TOUCH
if __name__ == '__main__':
    print_hello()