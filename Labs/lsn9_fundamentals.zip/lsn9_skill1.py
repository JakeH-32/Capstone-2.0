from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 9 - Fundamental Skill #1
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a function called draw_tree()  that outputs
# a tree to the console using ASCII art.  Call this function 3 times.
# ---------------------------------------------------------------------

# DO NOT TOUCH THIS FUNCTION
def draw_tree():
    print("  *  ")
    print(" *** ")
    print("*****")
    print("  |  ")


# Write Your Code Here

