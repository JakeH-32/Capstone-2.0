from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Popular Names
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement: Write a Python algorithm that gets a number, X,
# from the user, and prints out the X most popular names, starting with the most popular and working down.
# ---------------------------------------------------------------------
