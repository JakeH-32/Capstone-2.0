from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Bit Representation
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  In Python, write an algorithm that prompts the user
# for a number of bits and then outputs the number of different colors that
# could be represented by a single pixel.
# ---------------------------------------------------------------------
