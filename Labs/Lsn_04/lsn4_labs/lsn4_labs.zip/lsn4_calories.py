from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Calories
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a program using inputs age (years),
# weight (pounds), heart rate (beats per minute), and time (minutes),
# respectively. Output calories burned for men and women. 
# ---------------------------------------------------------------------
