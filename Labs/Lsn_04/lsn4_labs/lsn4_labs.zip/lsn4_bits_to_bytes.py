from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Bits to Bytes
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that prompts the user for a number
# of bits and then outputs the equivalent number of bytes.
# ---------------------------------------------------------------------
