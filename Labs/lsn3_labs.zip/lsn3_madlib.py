from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Input: Mad Lib
# Course: CS110
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a program that gets values from the user, and outputs
# it as Mad Lib (see lab for full details)
# ---------------------------------------------------------------------

