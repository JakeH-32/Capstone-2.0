from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: IPO:  Arrival Time
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT
# Write a program that  prompts the user for a
# distance to travel (in miles) and a speed (in mph) and outputs time of arrival in hours.
# NOTE: We think you can do this in 4 lines of code!
# ---------------------------------------------------------------------


