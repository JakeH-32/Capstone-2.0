from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: IPO:  Girl Scout Cookies
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT
# Write a program that prompts the user for the amount of money he/she
# has on hand.  Your program will then print out the number of girlscout
# cookie boxes (super six and specialty) he/she can purchase with this amount.
# See the lab writeup for exact prices.
# ---------------------------------------------------------------------



