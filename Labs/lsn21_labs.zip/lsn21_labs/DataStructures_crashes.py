from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Unique Crashes
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Create a Python function called get_accident_types
# that takes the name of a file as a parameter.  Your function should return a
# **set** containing all of the unique accident types.
# ---------------------------------------------------------------------

