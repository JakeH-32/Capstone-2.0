from cs110 import autograder

# ---------------------------------------------------------------------
# Lab Lesson 5: Atmospheric Layers
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that asks the user for the altitude in kilometers.
# Then output the corresponding layer (see lab writeup for details)
# ---------------------------------------------------------------------

