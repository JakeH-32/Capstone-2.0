from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 14 - Fundamental Skill #1
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a variable that asks the user for the
# number of times to loop.  Construct a FOR loop that loops this many times
# printing out a message each time (the message can be whatever you want)
# ---------------------------------------------------------------------

# This line has been provided to you.  DO NOT TOUCH.
num_times_to_loop = int(input())

# Write Your FOR Loop Here