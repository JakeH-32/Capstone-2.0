from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: ASCII Art
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a program that outputs a cat following 
# the format described above.
# ---------------------------------------------------------------------

# YOUR CODE GOES BELOW
