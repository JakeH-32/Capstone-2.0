from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Sorted Names
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python algorithm that asks the user for the
# number of names to process, and then gets that many values.  Print out
# the names in alphabetical order, with each name starting on a line.
# ---------------------------------------------------------------------

