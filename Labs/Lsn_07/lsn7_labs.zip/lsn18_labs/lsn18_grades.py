from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Grades
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Create a Python program that asks how many students
# are in a class, then prompts the user for each student’s grade (0-100).
# Then output the grades that are at least 10 points above the average.
# ---------------------------------------------------------------------

