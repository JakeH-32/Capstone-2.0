from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: 2 Letter Combinations
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Create a function called get_combinations that takes
# a list of characters as a parameter, and returns a list containing all
# of the 2-letter combinations.
# ---------------------------------------------------------------------

# Your Code Goes Here

