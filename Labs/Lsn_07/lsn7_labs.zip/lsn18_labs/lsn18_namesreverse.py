from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Names in Reverse
# Author: NAME GOES HERE
# Course: CS110Z, Spring 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Allow the user to enter names one at a time until they type the word 'END' (without quotes).
# After entering all the names, your algorithm will print the names in the reverse order that they were entered.
# ---------------------------------------------------------------------
