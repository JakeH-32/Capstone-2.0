from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Echo
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that gets a filename and letter from the user,
# and outputs every line that starts with a specified letter
# ---------------------------------------------------------------------

