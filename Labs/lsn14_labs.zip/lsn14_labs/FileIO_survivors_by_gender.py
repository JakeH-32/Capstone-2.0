from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Titanic Survivors (By Gender)
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that analyzes the titanic dataset
# and prints out how many males/females survived.
# ---------------------------------------------------------------------
