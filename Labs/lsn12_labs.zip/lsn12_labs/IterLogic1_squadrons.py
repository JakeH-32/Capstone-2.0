from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Squadrons
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that asks the user for the number of
# squadrons to input, and then gets each squadron's number.  Output the number
# of squadrons from 1st, 2nd, 3rd, and 4th groups.
# ---------------------------------------------------------------------

