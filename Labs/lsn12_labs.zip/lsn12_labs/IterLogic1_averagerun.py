from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Average Run
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  In, Python, write an algorithm that first asks the
# user how manyPFT run times to input and then gets that many values from the user.
# Output the average of all the run times.  You can assume there is at least one grade to input.
# ---------------------------------------------------------------------

