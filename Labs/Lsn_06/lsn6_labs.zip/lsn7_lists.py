from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 7, Merit Lists
# Course: CS110, Fall 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that prompts the user for a decimal
# GPA, APA, and MPA and report which meritorious list the cadet is on.
# ---------------------------------------------------------------------

