from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 7 - Fundamental Skill #2
# Course: CS110, Fall 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a program that gets a cadet's gpa, apa, and pea
# If the cadet is on probation (gpa, mpa, or apa < 2.0), print "Probation"
# Otherwise, print "No Probation"
# ---------------------------------------------------------------------

# THIS LINE IS GOOD.  DO NOT TOUCH!
gpa = float(input())
apa = float(input())
mpa = float(input())

# YOUR CODE STARTS HERE
