from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 9 - Triangle
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a function that computes the area of a triangle. You will name your function area_triangle().
# It has two parameters, the height of the triangle, height, and the length of the base, base.
# The area_triangle() function will output (i.e., print) the area of the triangle.
# ---------------------------------------------------------------------

# WRITE YOUR FUNCTION HERE


# Testing Code.  DO NOT TOUCH
if __name__ == "__main__":
    b = float(input())
    h = float(input())
    area_triangle(b, h)
