from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 8 - Practice Question #1
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write an input statement that will make the below print statement work
# ---------------------------------------------------------------------

# YOUR CODE GOES HERE


# THIS LINE IS GOOD.  DO NOT TOUCH!
print("Members of the class of", class_year, "arrived at USAFA in", class_year - 4)




