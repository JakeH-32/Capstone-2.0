from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 21 - Fundamental Skill #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You are being provided with a function called mini_sort that takes two numbers
# as parameters.  Modify this function so that it returns a tuple containing
# the numbers in ascending order.
# ---------------------------------------------------------------------

# YOUR FUNCTION GOES HERE
def mini_sort(num1, num2):
    return (num1, num2)

