from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Times Table
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that asks the user for a positive
# number and then outputs the multiplication table of that number 1-10.
# ---------------------------------------------------------------------

