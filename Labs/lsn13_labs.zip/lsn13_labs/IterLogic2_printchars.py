from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Printing ASCII Characters
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# LOGIC DESIGN
# Problem Statement:  Write a Python algorithm that asks the users for
# two ASCII characters (e.g., 'a', 'z'), and prints all of the characters
# between them (inclusive). 
# ---------------------------------------------------------------------


        