from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Counting
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python algorithm that gets three numbers
# from the user, X, Y, and Z.  Your algorithm should output all the numbers
# from X to Y, counting by Z.  You may assume that Z is non-zero. 
# ---------------------------------------------------------------------
