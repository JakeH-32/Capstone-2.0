from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Printing Coordinates
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python algorithm that prints the coordinates
# in a coordinate plane.  
# ---------------------------------------------------------------------

