from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 6, UOD
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Create a Python program that receives first the temperature
# (in degrees Fahrenheit) and second the wind speed (in knots) from the user.
# Then have it output the correct UOD
# ---------------------------------------------------------------------
