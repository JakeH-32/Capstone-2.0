from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 6, Speeding Ticket
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a program that gets a speed in miles per hour
# and then returns a string stating what kind of ticket a police
# officer should give the driver. See lab for details.
# ---------------------------------------------------------------------
