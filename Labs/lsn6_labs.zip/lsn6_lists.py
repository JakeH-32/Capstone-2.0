from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 6, Merit Lists
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write an algorithm that prompts the user for a decimal
# GPA, APA, and MPA and report which meritorious list the cadet is on.
# ---------------------------------------------------------------------

