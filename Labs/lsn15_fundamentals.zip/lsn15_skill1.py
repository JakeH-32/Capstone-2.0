from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 15 - Fundamental Skill #1
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a file called sample.txt.  Write
# a python file that opens this file, and prints all of its contents
# as a single string.
# ---------------------------------------------------------------------

