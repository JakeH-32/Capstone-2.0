from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 15 - Fundamental Skill #2
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a python program that creates a file called "output.txt" and
# prints a message of your choosing.
# ---------------------------------------------------------------------



