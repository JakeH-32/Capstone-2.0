from cs110 import autograder
import math

# ---------------------------------------------------------------------
# Lab: PFT Scores
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement: Using the list of pft scores below, grab one new score
# from the user, then print the average followed by the range.
#  See Lab for exact specification.
# ---------------------------------------------------------------------
pft_scores = [243, 394, 143, 288, 303, 473, 325, 273, 284, 198, 70, 289, 437, 329]

