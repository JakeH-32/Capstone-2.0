from cs110 import autograder
import math

# ---------------------------------------------------------------------
# Lab: Asteroids Collision Detection
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a function that determines if a spaceship has
# hit an asteroid.  See Lab for exact specification.
# ---------------------------------------------------------------------

