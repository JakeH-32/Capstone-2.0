from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 19 - Fundamental Skill #2
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You are being provided with an empty table.  Add the two rows
# described in the problem writeup
# ---------------------------------------------------------------------

squadron_table = []

# Append Row 1 here

# Append Row 2
