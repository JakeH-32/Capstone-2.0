from cs110 import autograder
import math

# ---------------------------------------------------------------------
# Lab: Lesson 9 - Practice Question #3
# Course: CS110, Spring 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a program that asks the user for the price of an item (in dollars/cents)
# Print out the equivalent price of the item in:
#    1.  British Pounds (1.25 USD per pound)
#    2.  Korean Won (1 Won == 0.00083 USD)
#    3.  Mexican Pesos (1 Peso == 53.81 Won)
# Print each currency amount on a separate line
# ---------------------------------------------------------------------



