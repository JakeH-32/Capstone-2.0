from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 9 - Practice Question #2
# Course: CS110, Spring 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Calculate and output the distance between two points,
# (x1, y1) and (x2, y2)
# ---------------------------------------------------------------------

# THESE LINES ARE GOOD.  DO NOT TOUCH!
x1 = float(input())
y1 = float(input())
x2 = float(input())
y2 = float(input())

# YOUR CODE GOES HERE





