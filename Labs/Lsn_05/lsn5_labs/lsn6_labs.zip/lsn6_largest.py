from cs110 import autograder

# ---------------------------------------------------------------------
# Lab Lesson 6: Largest Number
# Course: CS110, Fall 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a program that gets three numbers from the
# user, and prints the largest one.
# ---------------------------------------------------------------------
