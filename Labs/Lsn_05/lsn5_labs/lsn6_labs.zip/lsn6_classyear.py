from cs110 import autograder

# ---------------------------------------------------------------------
# Lab Lesson 6: Class Year
# Course: CS110, Fall 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python program that gets the user's class
# year as input, and outputs their cadet class. If the class year is before 2021,
# output "Graduate". Alternatively, if the class year is after 2024, output "Not a Cadet".
# ---------------------------------------------------------------------
