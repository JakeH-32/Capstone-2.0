from cs110 import autograder

# ---------------------------------------------------------------------
# Lab Lesson 6: Are You Positive?
# Course: CS110, Fall 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  Write a Python **program** that gets a number from the user:
#    - If the number is positive, print POSITIVE
#    - If the number is NOT positive, print NOT POSITIVE
# ---------------------------------------------------------------------
