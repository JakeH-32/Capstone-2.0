from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 6 - Fundamental Skill #1
# Course: CS110, Fall 2021
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a program that gets a temperature from the user.
# Modify the program to do the following:
#     - If the temperature is less than or equal to 32, print "Water Has Frozen"
#     - Otherwise (i.e., else), print "Above Water's Freezing Point"
# ---------------------------------------------------------------------

# THIS LINE IS GOOD.  DO NOT TOUCH!
temperature = float(input())

# YOUR CODE GOES BELOW HERE