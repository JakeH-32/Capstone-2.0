from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 5 - Fundamental Skill #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# You have been provided with a program that gets a course name and number (e.g., Math 243) from the user.
# Modify the program to do the following:
#     - If the course is equal to "CS110", print "You get to program!"
#     - Otherwise (i.e., else), print "Boo, no programming."
# ---------------------------------------------------------------------

# THIS LINE IS GOOD.  DO NOT TOUCH!
course_title = input()

# YOUR CODE STARTS HERE
