from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Hello World (Welcome to the Class)
# Course: CS110, Fall 2020
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Press the play button to see how Thonny works!  No Coding Required!
# ---------------------------------------------------------------------

# This line prints the words "Hello World" to the screen
# We will show you in future lessons how to make it do other stuff
print("Hello World")