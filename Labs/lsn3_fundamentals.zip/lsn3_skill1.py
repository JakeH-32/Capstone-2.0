from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 3 - Fundamental Skill #1
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Create a variable called "name", and set it equal to your name
# Don't forget quotes around your name!
# ---------------------------------------------------------------------
