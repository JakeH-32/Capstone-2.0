from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 4 - Fundamental Skill #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# The following program gets a distance and speed from the user, and
# calculates the travel time.  Unfortunately, the code
# does not work.  Analyze the code (and error message) and fix the problem.
# ---------------------------------------------------------------------
  
# Gets Distance from the User
distance = input()

# Gets Speed from the User
speed = input()

# Prints out the travel time
print(distance / speed)