from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Lesson 14 - Fundamental Skill #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# PROBLEM STATEMENT:
# Write a python program that creates a file called "output.txt" and
# prints a message of your choosing.
# ---------------------------------------------------------------------

