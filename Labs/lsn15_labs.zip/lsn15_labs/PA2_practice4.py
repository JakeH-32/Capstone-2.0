from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Practice Question #4
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  You have been provided with a file (fuelprices.csv)
# that contains monthly gasoline prices from 2006 - 2012.  Write a Python
# program that asks for a gas type.  Your program should then read the file
# and output the average price of gas
# for that gas type.
#
# Refer to the lab description for more info on how fuelprices.csv is organized.
# ---------------------------------------------------------------------



