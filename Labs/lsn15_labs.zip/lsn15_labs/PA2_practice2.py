from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Practice Question #2
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  You have been provided with a function that returns
# the nth value in a sequence.  Get a number from the user (x), and print the
# xth to the x+5th value in that sequence (6 numbers total).
# ---------------------------------------------------------------------

# This function returns the nth value in a sequence
def get_value(n):
    return (2 * n) + 1

# Your Code Goes Here
