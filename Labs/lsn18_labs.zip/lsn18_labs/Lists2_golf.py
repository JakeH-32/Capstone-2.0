from cs110 import autograder

# ---------------------------------------------------------------------
# Lab: Golf Team
# Course: CS110
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Problem Statement:  create an Python algorithm that inputs repeated
# pairs of cadet last-names followed by the golfer’s score until the word END.
# Your algorithm should output the member with the lowest score, and the %
# of cadets that were within 5 (inclusive) of the lowest score.
# ---------------------------------------------------------------------

